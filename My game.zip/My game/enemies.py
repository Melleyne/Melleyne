

enemies_startloc= {
    'Лёгкая': {'Курица': {'health': 30, 'damage': (0, 2), "money" : 5},
             'Свинья': {'health': 10, 'damage': (1, 3), "money" : 3},
             'Птица': {'health': 5, 'damage': (1, 3), "money" : 10}},
    'Средняя': {'Волк': {'health': 20, 'damage': (5, 20), "money" : 25},
               'Медведь': {'health': 25, 'damage': (10, 15), "money" : 35},
               'Змея': {'health': 15, 'damage': (1, 7), "money" : 20}},
    'Сложная': {'Стальной ёж': {'health': 50, 'damage': (20, 50), "money" : 500},
             'Гигантский слизь': {'health': 40, 'damage': (10, 75), "money" :500},
            }
}

first_boss = {
    "name" : "Голубая змея",
    "health" : 500,
    "damage": (25, 75),
    "money" : 1500,
    "drop_for_voin" : "Меч из клыка змеи" ,
    "drop_for_druid" : "Посох призыва змеи" ,
}
