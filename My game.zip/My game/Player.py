from Rase_info import *
from enemies import *
import random
from time import sleep
from weapon import *

player = {
    "name" : "" ,
    "rase" : "" ,
    "inventory" : [] ,
    "money" : 0 ,
    "class" : "",
    "Equipment_weapon" : "Кулаки",
    "Equipment_armor" : "Повседневная одежда",
    "Equipment_magic" : "Магический свет",
    "weapon_atack" : 0
}


slojnosty = {
    1 : "Лёгкая" ,
    2 : "Средняя" ,
    3 : "Сложная" ,
}


com_list = {
    1 : "1 - инвентарь*" ,
    2 : "2 - путешествие" ,
    3 : "3 - битва ",
    4 : "4 - магазин",
    5 : "5 - экипировка"
}


location = {
    1 : "Стартовая деревня" ,
    2 : "Магический лес" ,
    3 : "Пещера дракона" ,
    4 : "Замок короля демонов"
}

start_location_option = {
    1 : "1 - Гильдия охотников" ,
    2 : "2 - Главная площадь" ,
    3 : "3 - Мэрия" ,
    5 : "4 - Тренировочный зал" ,
    6 : "5 - додзё"
}

#магазин зелий
zel_list = {
    1 : "Зелье востоновления (10hp)" ,
    2 : "Зелье востоновления (25hp)" ,
    3 : "Зелье востоновления (50hp)" ,
    4 : "Зелье востоновления (75hp)" ,
    5 : "Зелье востоновления (100hp)" ,
    6 : "Зелье щита (+100hp)" ,
    7 : "Зелье востоновления маны (10mp)" ,
    8 : "Зелье востоновления маны (25mp)" ,
    9 : "Зелье востоновления маны (50mp)" ,
    10 : "Зелье востоновления маны (75mp)" ,
    11 : "Зелье востоновления маны (100mp)" ,
}
zel_price = {
    "Зелье востоновления (10hp)" :  25,
    "Зелье востоновления (25hp)" :  50,
    "Зелье востоновления (50hp)" :  75,
    "Зелье востоновления (75hp)" :  100,
    "Зелье востоновления (100hp)" : 150,
    "Зелье щита (+100hp)" :  500,
    "Зелье востоновления маны (10mp)" : 25,
    "Зелье востоновления маны (25mp)" : 50,
    "Зелье востоновления маны (50mp)" : 75,
    "Зелье востоновления маны (75mp)" : 100,
    "Зелье востоновления маны (100mp)" : 150
}

#магазин заклинаний
magic_shop_list = {
    1 : "Магическая стрела" ,
    2 : "Огненый шар" ,
    3 : "Ураган тьмы" ,
    4 : "Шар света" ,
    5 : "Усиление атаки" ,
    6 : "Отравление",
}

magic_shop_price = {
    "Магическая стрела" : 500,
    "Огненый шар" : 750,
    "Ураган тьмы" : 1000,
    "Шар света" : 1000,
    "Усиление атаки" : 500,
    "Отравление" : 100,
}


weapon_shop_list = []



weapon_shop_price = {
    
}

#додзё
dodgo_stel = {
    1 : "Одномечевой стиль",
    2 : "Двухмечевой стиль",
    3 : "Трёхмечевой стиль",
    4 : "Четырёхмечевой стиль",
}


print("Добро пожаовать в новый мир, введи своё имя:")
player_name = input()
player["name"] = player_name


if player["name"] == "Марк":
    player["money"] = 1000000


print("Приятно познакомится - ", player["name"])

print("Как только ты назвал своё имя, выбери будующую рассу -")
print("Вот весь список расс :")
for i in rase: #выбор рассы
    print(rase[i])
rs = input()
player["rase"] = rs 
print("Отлично, твоя расса ", player["rase"])
print("Засчёт твоей рассы ты получаешь следующие характеристики:", )

if player["rase"] == "Человек": #статый расс
    print("Здоровье - ", Human["hp"], "Урон - ", Human["damage"], "Защита - ", Human["armor"], "Оружие -", Human["weapon"], "Стартовое оружие -", Human["start_weapon"], player["inventory"].append(Human["start_weapon"]))
elif player["rase"] == "Эльф":
    print("Здоровье - ", Elf["hp"], "Урон - ", Elf["damage"], "Защита - ", Elf["armor"], "Оружие -", Elf["weapon"],  "Стартовое оружие -", Elf["start_weapon"], player["inventory"].append(Elf["start_weapon"]))
elif player["rase"] == "Тёмный эльф":
    print("Здоровье - ", dark_Elf["hp"], "Урон - ", dark_Elf["damage"], "Защита - ", dark_Elf["armor"], "Оружие -",  dark_Elf["weapon"], "Стартовое оружие -",dark_Elf["start_weapon"], player["inventory"].append(dark_Elf["start_weapon"]))


print("Отлично, теперь выбери свой класс:")
for i in clas: #выбор класса
    print(clas[i])
player["class"] = input()

if player["class"] == "Воин" and player["rase"] == "Человек": #Расчёт статов
    player_hp = Human["hp"] + warior["hp"]
    player_damage = Human["damage"] + warior["damage"]
    player_armor = Human["armor"] + warior["armor"]
    player_mana = Human["mana"] + warior["mana"]
    player_stamina = Human["stamina"] + warior["stamina"]
elif player["class"] == "Друид" and player["rase"] == "Человек":
    player_hp = Human["hp"] + druid["hp"]
    player_damage = Human["damage"] + druid["damage"]
    player_armor = Human["armor"] + druid["armor"]
    player_mana = Human["mana"] + druid["mana"]
    player_stamina = Human["stamina"] + druid["stamina"]
elif player["class"] == "Воин" and player["rase"] == "Эльф":
    player_hp = Elf["hp"] + warior["hp"]
    player_damage = Elf["damage"] + warior["damage"]
    player_armor = Elf["armor"] + warior["armor"]
    player_mana = Elf["mana"] + warior["mana"]
    player_stamina = Elf["stamina"] + warior["stamina"]
elif player["class"] == "Друид" and player["rase"] == "Эльф":
    player_hp = Elf["hp"] + druid["hp"]
    player_damage = Elf["damage"] + druid["damage"]
    player_armor = Elf["armor"] + druid["armor"]
    player_mana = Elf["mana"] + druid["mana"]
    player_stamina = Elf["stamina"] + druid["stamina"]
elif player["class"] == "Воин" and player["rase"] == "Тёмный Эльф":
    player_hp = dark_Elf["hp"] + warior["hp"]
    player_damage = dark_Elf["damage"] + warior["damage"]
    player_armor = dark_Elf["armor"] + warior["armor"]
    player_mana = dark_Elf["mana"] + warior["mana"]
    player_stamina = dark_Elf["stamina"] + warior["stamina"]
elif player["class"] == "Друид" and player["rase"] == "Тёмный Эльф":
    player_hp = dark_Elf["hp"] + druid["hp"]
    player_damage = dark_Elf["damage"] + druid["damage"]
    player_armor = dark_Elf["armor"] + druid["armor"]
    player_mana = dark_Elf["mana"] + druid["mana"]
    player_stamina = dark_Elf["stamina"] + druid["stamina"]



player_stats = {
    "hp" : player_hp,
    "damage" : player_damage,
    "armor" : player_armor,
    "mana" : player_mana,
    "stamina" : player_stamina
}

print("Здоровье - ", player_stats["hp"], "Урон - ", player_stats["damage"], "Защита - ", player_stats["armor"], "Мана - " , player_stats["mana"], "Выносливость -", player_stats["stamina"])

print("Добро пожаловать в новый мир приключений и испытаний")

print("Вы наделены магической способностью, для вызова используйте команду - меню")
com = input("Введите команду...")
if com == "меню":  #Начало
    print("1 - Путешествие")
    com = int(input("Введите номер команды : "))
    if com == 1:
        for i in location:
            print(location[i])
        loc = input("Введити название локации : ")
        if loc == "Стартовая деревня":
            print("Ты прибыл в стартовую деревню : Пустырь")
            print("Выбери точку перемещения по городу:")
            print("Гильдия охотников")
            start_vilag_option = int(input())
            if start_vilag_option == 1:
                print("Добро пожаловать в гильдию охотников, желаете вступить к нам? ")
                print(" Я хочу вступить в вашу гильдию")
                print("Отлично, теперь осталось заполнить пару документов и вы официально участник нашей гильдии, не волнуйтесь это быстро")
                sleep(10)
                print("Спустя 4 часа...")
                print("Вот и всё, поздравляю вы новый охотник*")
                print("Теперь вы можете взять задание по охоте на врага ")
                print("(Система): Теперь ты сможешь сражаться в меню")


def choose_enemy_startloc(dif_stlc): #выбор врага в старт локе
    if dif_stlc in enemies_startloc:
                enemy_name = random.choice(list(enemies_startloc[dif_stlc].keys()))
                enemy_stats = enemies_startloc[dif_stlc][enemy_name]
                return enemy_name, enemy_stats['health'], enemy_stats['damage'], enemy_stats["money"]

def battle(enemy_name, enemy_health, enemy_damage, enemy_money): #скрипт битвы
    player_health = player_stats["hp"] # Здоровье игрока
    player_mana = player_stats["mana"] # Мана игрока
    player_magic = player["Equipment_magic"]
    player_def = player_stats["armor"] / 100
    if player["Equipment_weapon"] == "Кулаки":
        player_dop_dam = kulak["dop_dam"]
    elif player["Equipment_weapon"] == "Меч из светлого дерева":
        player_dop_dam = Light_wood_sword["dop_dam"]
    elif player["Equipment_weapon"] == "Меч из тёмного дерева":                             
        player_dop_dam = Dark_wood_sword["dop_dam"]
    elif player["Equipment_weapon"] == "Меч из клыка змеи":
        player_dop_dam = Blue_snake_sword["dop_dam"]
    elif player["Equipment_weapon"] == "Старый меч":
        player_dop_dam = old_sword["dop_dam"]

    if player["Equipment_magic"] == "Магическая стрела":
        player_magic_dop_dam = magic_arow["dop_dam"]
    elif player["Equipment_magic"] == "Огненый шар":
        player_magic_dop_dam = fire_ball["dop_dam"]
    elif player["Equipment_magic"] == "Ураган тьмы":
        player_magic_dop_dam = dark_wind["dop_dam"]
    elif player["Equipment_magic"] == "Шар света":
        player_magic_dop_dam = light_ball["dop_dam"]
    elif player["Equipment_magic"] == "Отравление":
        player_magic_dop_dam = Poison_magic["dop_dam"]
    
    
    print(f"Вы сражаетесь с {enemy_name}, у него {enemy_health} здоровья.")

    while enemy_health > 0 and player_health > 0:
        # Игрок атакует врага
        print("Ваш ход, выберите действие")
        print("1 - Атаковать")
        print("2 - Инвентарь")
        fight_opt = int(input())
        if fight_opt == 1 :
            print("Выбери желаемый тип атаки: ")
            print("1 - Атака ближнего боя 2 Атака магией")
            atk_tipe = int(input())
            if atk_tipe == 1 and player["Equipment_weapon"] == "Кулаки":
                print("Вы наносите удар кулаками")
                enemy_health -= player_damage
                print(f"Вы нанесли {player_damage} урона {enemy_name}. Осталось здоровья врага: {enemy_health}")
            elif atk_tipe == 1 and player["Equipment_weapon"] != "":
                print("Вы наносите удар с помощью ", player["Equipment_weapon"])
                player_damage = player_stats["damage"]
                enemy_health -= player_damage
                print(f"Вы нанесли {player_damage} урона {enemy_name}. Осталось здоровья врага: {enemy_health}")
                if player_dop_dam != 0:
                    enemy_health -= player_dop_dam
                    print(f"Вы наносите доп урон {player_dop_dam}  {enemy_name} . Осталось здоровья врага: {enemy_health}")
            elif atk_tipe == 2 and player["Equipment_magic"] == "Усиление атаки":
                print("Вы решили увеличить атаку на 1 бой")
                player_damage += 5
                print("Теперь ваш урон - ", player_damage)
                player_mana -= player_magic["mana_cost"]
            elif atk_tipe == 2 and player["Equipment_magic"] != "Заклинание света":
                print("Вы наносите удар с помощью ", player["Equipment_magic"])
                player_damage = player_stats["damage"]
                print("Ваш урон составит", player_damage) # Урон, который игрок наносит врагу
                enemy_health -= player_damage
                print(f"Вы нанесли {player_damage} урона {enemy_name}. Осталось здоровья врага: {enemy_health}")
                if player_magic_dop_dam != 0:
                    enemy_health -=  player_magic_dop_dam
                    print(f"Вы наносите доп урон {player_magic_dop_dam}  {enemy_name} . Осталось здоровья врага: {enemy_health}")
                player_mana -= player_magic["mana_cost"]
            else:
                print("Судя по всему вы решили осветить врага")
            sleep(3)
        elif fight_opt == 2: #Зелья
            print(player["inventory"])
            inv_opt = int(input("Введите названия зелья или порядковый номер: "))
            for i in zel_list:
                print(zel_list[i])
            if "Зелье востоновления (10hp)" in player["inventory"] and inv_opt == 1:
                player_health_zel = player_health + 10
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 10
                player["inventory"].remove("Зелье востоновления (10hp)")
            elif "Зелье востоновления (25hp)" in player["inventory"] and inv_opt == 2:
                player_health_zel = player_health + 25
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 25
                player["inventory"].remove("Зелье востоновления (25hp)")
            elif "Зелье востоновления (50hp)" in player["inventory"] and inv_opt == 3:
                player_health_zel = player_health + 50
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 50
                player["inventory"].remove("Зелье востоновления (50hp)")
            elif "Зелье востоновления (75hp)" in player["inventory"] and inv_opt == 4:
                player_health_zel = player_health + 75
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 75
                player["inventory"].remove("Зелье востоновления (75hp)")
            elif "Зелье востоновления (100hp)" in player["inventory"] and inv_opt == 5:
                player_health_zel = player_health + 100
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 100
                player["inventory"].remove("Зелье востоновления (100hp)")
            elif "Зелье щита (+100hp)" in player["inventory"] and inv_opt == 6:  
                player_health += 100
                player["inventory"].remove("Зелье щита (+100hp)")
            elif "Зелье востоновления маны (10mp)" in player["inventory"] and inv_opt == 7:
                player_mana_zel = player_mana + 10
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 10
                player["inventory"].remove("Зелье востоновления маны (10mp)")
            elif "Зелье востоновления маны (25mp)" in player["inventory"] and inv_opt == 8:
                player_mana_zel = player_mana + 25
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 25
                player["inventory"].remove("Зелье востоновления маны (25mp)")
            elif "Зелье востоновления маны (50mp)" in player["inventory"] and inv_opt == 9:
                player_mana_zel = player_mana + 50
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 50
                player["inventory"].remove("Зелье востоновления маны (50mp)")
            elif "Зелье востоновления маны (75mp)" in player["inventory"] and inv_opt == 10:
                player_mana_zel = player_mana + 75
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 75
                player["inventory"].remove("Зелье востоновления маны (75mp)")
            elif "Зелье востоновления маны (100mp)" in player["inventory"] and inv_opt == 11:
                player_mana_zel = player_mana + 100
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 100
                player["inventory"].remove("Зелье востоновления маны (100mp)")
            print("Твоё здоровье - ", player_health)
            print("Твоя мана - ", player_mana)
        

        if enemy_health <= 0:
            print(f"Вы победили {enemy_name}!")
            player["money"] += enemy_money
            print(f"Ваш баланс пополнился на - ", enemy_money, "и теперь равен -", player["money"])
            break

        # Враг атакует игрока
        enemy_attack = random.randint(*enemy_damage)  # Урон, который враг наносит игроку
        player_health -= enemy_attack * player_def
        print(f"{enemy_name} нанёс вам {enemy_attack} урона. Осталось здоровья игрока: {player_health}")
        sleep(3)

        if player_health <= 0:
            print("Вы проиграли бой!")
            break

def battle_vs_first_boss(enemy_name, enemy_health, enemy_damage, enemy_money, enemy_drop_for_voin, enemy_drop_for_druid): #срипт битвы с боссом
    player_health = player_stats["hp"] # Здоровье игрока
    player_mana = player_stats["mana"] # Мана игрока
    player_damage = player_stats["damage"]
    player_magic = player["Equipment_magic"]
    player_def = player_stats["armor"] / 100
    if player["Equipment_weapon"] == "Кулаки":
        player_dop_dam = kulak["dop_dam"]
    elif player["Equipment_weapon"] == "Меч из светлого дерева":
        player_dop_dam = Light_wood_sword["dop_dam"]
    elif player["Equipment_weapon"] == "Меч из тёмного дерева":                             
        player_dop_dam = Dark_wood_sword["dop_dam"]
    elif player["Equipment_weapon"] == "Меч из клыка змеи":
        player_dop_dam = Blue_snake_sword["dop_dam"]
    elif player["Equipment_weapon"] == "Старый меч":
        player_dop_dam = old_sword["dop_dam"]

    if player["Equipment_magic"] == "Магическая стрела":
        player_magic_dop_dam = magic_arow["dop_dam"]
    elif player["Equipment_magic"] == "Огненый шар":
        player_magic_dop_dam = fire_ball["dop_dam"]
    elif player["Equipment_magic"] == "Ураган тьмы":
        player_magic_dop_dam = dark_wind["dop_dam"]
    elif player["Equipment_magic"] == "Шар света":
        player_magic_dop_dam = light_ball["dop_dam"]
    elif player["Equipment_magic"] == "Отравление":
        player_magic_dop_dam = Poison_magic["dop_dam"]
    
    
    print(f"Вы сражаетесь с {enemy_name}, у него {enemy_health} здоровья.")

    while enemy_health > 0 and player_health > 0:
        # Игрок атакует врага
        print("Ваш ход, выберите действие")
        print("1 - Атаковать")
        print("2 - Инвентарь")
        fight_opt = int(input())
        if fight_opt == 1 :
            print("Выбери желаемый тип атаки: ")
            print("1 - Атака ближнего боя 2 Атака магией")
            atk_tipe = int(input())
            if atk_tipe == 1 and player["Equipment_weapon"] == "Кулаки":
                print("Вы наносите удар кулаками")
                enemy_health -= player_damage / 2
                print(f"Вы нанесли {player_damage} урона {enemy_name}. Осталось здоровья врага: {enemy_health}")
            elif atk_tipe == 1 and player["Equipment_weapon"] != "":
                print("Вы наносите удар с помощью ", player["Equipment_weapon"])
                player_damage = player_stats["damage"]
                enemy_health -= player_damage / 2
                print(f"Вы нанесли {player_damage} урона {enemy_name}. Осталось здоровья врага: {enemy_health}")
                if player_dop_dam != 0:
                    enemy_health -= player_dop_dam
                    print(f"Вы наносите доп урон {player_dop_dam}  {enemy_name} . Осталось здоровья врага: {enemy_health}")
            elif atk_tipe == 2 and player["Equipment_magic"] == "Усиление атаки":
                print("Вы решили увеличить атаку на 1 бой")
                player_damage += 5
                print("Теперь ваш урон - ", player_damage)
                player_mana -= player_magic["mana_cost"]
            elif atk_tipe == 2 and player["Equipment_magic"] != "Заклинание света":
                print("Вы наносите удар с помощью ", player["Equipment_magic"])
                player_damage = player_stats["damage"]
                print("Ваш урон составит", player_damage) # Урон, который игрок наносит врагу
                enemy_health -= player_damage / 2
                print(f"Вы нанесли {player_damage} урона {enemy_name}. Осталось здоровья врага: {enemy_health}")
                if player_magic_dop_dam != 0:
                    enemy_health -=  player_magic_dop_dam
                    print(f"Вы наносите доп урон {player_magic_dop_dam}  {enemy_name} . Осталось здоровья врага: {enemy_health}")
                player_mana -= player_magic["mana_cost"]
            else:
                print("Судя по всему вы решили осветить врага")
            sleep(3)
        elif fight_opt == 2: #Зелья
            print(player["inventory"])
            inv_opt = int(input("Введите названия зелья или порядковый номер: "))
            for i in zel_list:
                print(zel_list[i])
            if "Зелье востоновления (10hp)" in player["inventory"] and inv_opt == 1:
                player_health_zel = player_health + 10
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 10
                player["inventory"].remove("Зелье востоновления (10hp)")
            elif "Зелье востоновления (25hp)" in player["inventory"] and inv_opt == 2:
                player_health_zel = player_health + 25
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 25
                player["inventory"].remove("Зелье востоновления (25hp)")
            elif "Зелье востоновления (50hp)" in player["inventory"] and inv_opt == 3:
                player_health_zel = player_health + 50
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 50
                player["inventory"].remove("Зелье востоновления (50hp)")
            elif "Зелье востоновления (75hp)" in player["inventory"] and inv_opt == 4:
                player_health_zel = player_health + 75
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 75
                player["inventory"].remove("Зелье востоновления (75hp)")
            elif "Зелье востоновления (100hp)" in player["inventory"] and inv_opt == 5:
                player_health_zel = player_health + 100
                if player_health_zel >= player_stats["hp"]:
                    player_health = player["hp"]
                else:
                    player_health += 100
                player["inventory"].remove("Зелье востоновления (100hp)")
            elif "Зелье щита (+100hp)" in player["inventory"] and inv_opt == 6:  
                player_health += 100
                player["inventory"].remove("Зелье щита (+100hp)")
            elif "Зелье востоновления маны (10mp)" in player["inventory"] and inv_opt == 7:
                player_mana_zel = player_mana + 10
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 10
                player["inventory"].remove("Зелье востоновления маны (10mp)")
            elif "Зелье востоновления маны (25mp)" in player["inventory"] and inv_opt == 8:
                player_mana_zel = player_mana + 25
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 25
                player["inventory"].remove("Зелье востоновления маны (25mp)")
            elif "Зелье востоновления маны (50mp)" in player["inventory"] and inv_opt == 9:
                player_mana_zel = player_mana + 50
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 50
                player["inventory"].remove("Зелье востоновления маны (50mp)")
            elif "Зелье востоновления маны (75mp)" in player["inventory"] and inv_opt == 10:
                player_mana_zel = player_mana + 75
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 75
                player["inventory"].remove("Зелье востоновления маны (75mp)")
            elif "Зелье востоновления маны (100mp)" in player["inventory"] and inv_opt == 11:
                player_mana_zel = player_mana + 100
                if player_mana_zel >= player_stats["mana"]:
                    player_mana = player["mana"]
                else:
                    player_mana += 100
                player["inventory"].remove("Зелье востоновления маны (100mp)")
            print("Твоё здоровье - ", player_health)
            print("Твоя мана - ", player_mana)
        

        if enemy_health <= 0:
            print(f"Вы победили {enemy_name}!")
            player["money"] += enemy_money
            print(f"Ваш баланс пополнился на - ", enemy_money, "и теперь равен -", player["money"])
            if player["class"] ==  "Воин":
                player["inventory"].append(enemy_drop_for_voin)
                print("Вы получили", enemy_drop_for_voin)
            elif player["class"] == "Друин":
                player["inventory"].append(enemy_drop_for_druid)
                print("Вы получили", enemy_drop_for_druid)
            break

        # Враг атакует игрока
        enemy_attack = random.randint(*enemy_damage)  # Урон, который враг наносит игроку
        player_health -= enemy_attack * player_def
        print(f"{enemy_name} нанёс вам {enemy_attack} урона. Осталось здоровья игрока: {player_health}")
        sleep(3)

        if player_health <= 0:
            print("Вы проиграли бой!")
            break

def Select_shop(): #Магазины
    player_money = player["money"]
    shop = int(input("Введите номер магазина из списка: 1 - Лавка зельевара 2 - Лавка колдуна"))
    if shop == 1: #Магазин зелий
        print("{Продавец зелий}:", "Добро пожаловать в мою лавку путник у меня есть различные зелья на любой вкус и цвет")
        for i in zel_list:
            print(zel_list[i])
        zel = int(input("Выбирай любое зелье(порядковй номер начиная с 1), конечно если хватит денег:"))
        if zel == 1 and player_money >= 25:
            print("Ты успешно преобрёл Зелье востоновления (10hp)")
            player["inventory"].append("Зелье востоновления (10hp)")
            player["money"] -= 25
        elif zel == 2 and player_money >= 50:
            print("Ты успешно преобрёл Зелье востоновления (25hp)")
            player["inventory"].append("Зелье востоновления (25hp)")
            player["money"] -= 50
        elif zel == 3 and player_money >= 75:
            print("Ты успешно преобрёл Зелье востоновления (50hp)")
            player["inventory"].append("Зелье востоновления (50hp)")
            player["money"] -= 75
        elif zel == 4 and player_money >= 100:
            print("Ты успешно преобрёл Зелье востоновления (75hp)")
            player["inventory"].append("Зелье востоновления (75hp)")
            player["money"] -= 100
        elif zel == 4 and player_money >= 100:
            print("Ты успешно преобрёл Зелье востоновления (75hp)")
            player["inventory"].append("Зелье востоновления (75hp)")
            player["money"] -= 100
        elif zel == 5 and player_money >= 150:
            print("Ты успешно преобрёл Зелье востоновления (100hp)")
            player["inventory"].append("Зелье востоновления (100hp)")
            player["money"] -= 150
        elif zel == 6 and player_money >= 500:
            print("Ты успешно преобрёл Зелье щита (+100hp)")
            player["inventory"].append("Зелье щита (+100hp)")
            player["money"] -= 500
        elif zel == 7 and player_money >= 25:
            print("Ты успешно преобрёл Зелье востоновления маны (10mp)")
            player["inventory"].append("Зелье востоновления маны (10mp)")
            player["money"] -= 25
        elif zel == 8 and player_money >= 50:
            print("Ты успешно преобрёл Зелье востоновления маны (25mp)")
            player["inventory"].append("Зелье востоновления маны (25mp)")
            player["money"] -= 50
        elif zel == 9 and player_money >= 75:
            print("Ты успешно преобрёл Зелье востоновления маны (50mp)")
            player["inventory"].append("Зелье востоновления маны (50mp)")
            player["money"] -= 75
        elif zel == 10 and player_money >= 100:
            print("Ты успешно преобрёл Зелье востоновления маны (75mp)")
            player["inventory"].append("Зелье востоновления маны (75mp)")
            player["money"] -= 100
        elif zel == 11 and player_money >= 100:
            print("Ты успешно преобрёл Зелье востоновления маны (75mp)")
            player["inventory"].append("Зелье востоновления маны (75mp)")
            player["money"] -= 100
        elif zel == 12 and player_money >= 150:
            print("Ты успешно преобрёл Зелье востоновления маны (100mp)")
            player["inventory"].append("Зелье востоновления маны (100mp)")
            player["money"] -= 150
        else:
            print("Либо ты не правильно выбрал товар, либо у тебя мало денег")
    elif shop == 2: #Магазин магии
        print("Добро пожаловать в мою лавку заклинаний")
        print("Здесь ты сможешь купить фолиант заклинаний и изучить его")
        print("Вот весь мой ассортимент: ")
        for i in magic_shop_list:
            print(magic_shop_list[i])
        magic = int(input("Введите порядковый номер заклинания начиная с 1"))
        if magic == 1 and player_money >= 500:
            print("Ты успешно преобрёл Магическую стрелу")
            player["inventory"].append("Магическая стрела")
            player["money"] -= 500
        elif magic == 2 and player_money >= 750:
            print("Ты успешно преобрёл Огненый шар")
            player["inventory"].append("Огненый шар")
            player["money"] -= 750
        elif magic == 3 and player_money >= 1000:
            print("Ты успешно преобрёл Ураган тьмы")
            player["inventory"].append("Ураган тьмы")
            player["money"] -= 1000
        elif magic == 4 and player_money >= 1000:
            print("Ты успешно преобрёл Шар света")
            player["inventory"].append("Шар света")
            player["money"] -= 1000
        elif magic == 5 and player_money >= 500:
            print("Ты успешно преобрёл Усиление атаки")
            player["inventory"].append("Усиление атаки")
            player["money"] -= 500
        elif magic == 6 and player_money >= 100:
            print("Ты успешно преобрёл Отравление")
            player["inventory"].append("Отравление")
            player["money"] -= 100
        else:
            print("Либо ты не правильно выбрал товар, либо у тебя мало денег")
            for i in magic_shop_price:
                print(magic_shop_price[i])
    elif shop == 3:
        print("Добро пожаловать в магазин оружия, введи желаемое оружие из списка:")
        for i in weapon_shop_list:
            print(weapon_shop_list[i])
        opt = input("Введи название меча")
        if opt == "Стальная катана" and "Стальная катана" in weapon_shop_list:
            player["inventory"].append("Стальная катана")
        






def menu_option(com):
    for i in com_list:
        print(com_list[i])
    com = int(input("Введите номер команды : "))
    if com == 1:
        print(player["inventory"])
    elif com == 2:
        for i in location:
            print(location[i])
        loc = input("Введити название локации : ")
        if loc == "Стартовая деревня" or 1:
            print("Ты прибыл в стартовую деревню : Пустырь")
        for sv in start_location_option:
                print(start_location_option[sv])
        start_vilag_option = int(input())
        if start_vilag_option == 2:
            print("Вы прибыли на главную площадь")
            sleep(2)
            print("В центре вы замечаете гигантскую статую воина")
            sleep(2)
            print("На ней написано, лишь достойный сможет стать моим приемликом")
            sleep(2)
            print("Вы замечаете, что шар в основании статуии светится, дотронуться?")
            next_lock = input("Да - Нет ")
            if next_lock == "Да":
                print("Как только вы дотронулись до шара, огромный столб света удар по вам")
                sleep(5)
                print("Спустя время вы очнулись, перед вами огромная железная дверь")
                sleep(2)
                print("Вы слышите громкий рык")
                sleep(2)
                print("В этот момент дверь распахнулась и вы увидели гиганского змея")
                sleep(2)
                print("Перед вами предстал босс Голубой змей")
                sleep(2)
                print("Он покрыт железной чешуёй")
                print("Весь получаемый урон босом уменьшен в двое")
                enemy_name = first_boss["name"]
                enemy_health = first_boss["health"]
                enemy_damage = first_boss["damage"]
                enemy_money = first_boss["money"]
                enemy_drop_for_voin = first_boss["drop_for_voin"]
                enemy_drop_for_druid = first_boss["drop_for_druid"]
                battle_vs_first_boss(enemy_name, enemy_health, enemy_damage, enemy_money, enemy_drop_for_voin, enemy_drop_for_druid)
        elif start_vilag_option == 4:
            hp_gym_cd = 0
            def_gym_cd = 0
            dam_gym_cd = 0
            hp_gym_time = 0
            def_gym_time = 0
            dam_gym_time = 0
            print("Добро пожаловать в gym")
            print("Выберите желаемую тренировку:")
            print("1 - Здоровье")
            print("2 - Защита")
            print("3 - Урон")
            gym_opt = int(input())
            if gym_opt == 1 and hp_gym_cd == 0:
                print("Отлично, тебя ждут толгие и мучительные тренировки")
                while hp_gym_time !=100:
                    print(hp_gym_time,"%")
                    hp_gym_time += 10
                    sleep(5)
                player_stats["hp"] += 10
                print("тренировка закончилась, теперь твоё здоровье")
                print(player_stats["hp"])
                hp_gym_time = 0
                hp_gym_cd = 1
                dam_gym_cd = 0
                def_gym_cd = 0
            elif gym_opt == 2 and def_gym_cd == 0:
                print("Отлично, тебя ждут толгие и мучительные тренировки")
                while def_gym_time !=100:
                    print(def_gym_time,"%")
                    def_gym_time += 10
                    sleep(5)
                player_stats["armor"] += 1
                print("тренировка закончилась, теперь твоё здоровье")
                print(player_stats["armor"])
                def_gym_time = 0
                def_gym_cd = 1
                dam_gym_cd = 0
                hp_gym_cd = 0
            elif gym_opt == 3 and dam_gym_cd == 0:
                print("Отлично, тебя ждут толгие и мучительные тренировки")
                while dam_gym_time !=100:
                    print(dam_gym_time,"%")
                    dam_gym_time += 10
                    sleep(5)
                player_stats["damage"] += 1
                print("тренировка закончилась, теперь твоё здоровье")
                print(player_stats["damage"])
                dam_gym_time = 0
                dam_gym_cd = 1
                def_gym_cd = 0
                hp_gym_cd = 0
        elif start_vilag_option == 3:
            print("Добро пожаловать в мэрию")
            print("Здесь ты можешь отправиться на работу, согласен?")
            a = input()
            if a == "Да" :
                print("Вы отправляетесь на завод")
                sleep(30)
                print("Поздравляю! Вы отработали смену")
                dohod = random.randint(100, 1000)
                print("Твоя зарплата - ", dohod)
                player["money"] += dohod
        elif start_vilag_option == 5:
            print("Добро пожаловать в наше додзё")
            print("Выбери желаемый стиль боя:")
            for i in dodgo_stel:
                print(dodgo_stel[i])
            stel = int(input("Введи порядковый номер стля"))
            if stel == 1:
                print("Хорошо, начнём тренировки")
                sleep(10)
                print("Прекрасно, теперь ты можешь купить катану ")
                weapon_shop_list.append("Стальная катана")
            elif stel == 2:
                print("Хорошо, начнём тренировки")
                sleep(20)
                print("Прекрасно, теперь ты можешь купить две катаны ")
                weapon_shop_list.append("Стальные катаны")
            elif stel == 3:
                print("Хорошо, начнём тренировки")
                sleep(30)
                print("Прекрасно, теперь ты можешь купить три катаны ")
                weapon_shop_list.append("Тёмные катаны")
            elif stel == 4:
                print("Я даже не буду спрашивать зачем тебе это")
                sleep(20)
                print("Я удивлён что ты решил обучится этому стилю")
                print("Прекрасно, теперь ты можешь купить Легендарная катана ")
                weapon_shop_list.append("Легендарная катана")
    elif com == 3:
        for i in location:
            print(location[i])
        loc = input("Введити название локации : ")
        if loc == "Стартовая деревня" or 1:
            for i in slojnosty:
                print(slojnosty[i])
            dif_stlc = input("Введи сложность врага")
            selected_enemy, enemy_health, enemy_damage, enemy_money = choose_enemy_startloc(dif_stlc)
            battle(selected_enemy, enemy_health, enemy_damage, enemy_money)
    elif com == 4:
        Select_shop()
    elif com == 5:

        print("Добро пожаловать в экипировку")
        print("Здесь вы можете выбрать своё снаряжение")
        print(player["inventory"])
        print("Что бы выбрать экипировку напишите её название, проверить свою экипировку вы сможете в меню под командой 6")
        a = input()
        if "Старый меч" in player["inventory"] and a == "Старый меч":
            player["inventory"].append(player["Equipment_weapon"])
            player["inventory"].remove("Старый меч")
            player_stats["damage"] -= player["weapon_atack"]
            player["Equipment_weapon"] = "Старый меч"
            player_stats["damage"] += old_sword["atack"]
            player["weapon_atack"] = old_sword["atack"]
        elif "Меч из светлого дерева" in player["inventory"] and a == "Меч из светлого дерева" :
            player["inventory"].append(player["Equipment_weapon"])
            player["inventory"].remove("Меч из светлого дерева")
            player_stats["damage"] -= player["weapon_atack"]
            player["Equipment_weapon"] = "Меч из светлого дерева"
            player_stats["damage"] += Light_wood_sword["atack"]
            player["weapon_atack"] = Light_wood_sword["atack"]
        elif "Меч из тёмного дерева" in player["inventory"] and a == "Меч из тёмного дерева" :
            player["inventory"].append(player["Equipment_weapon"])
            player["inventory"].remove("Меч из тёмного дерева")
            player_stats["damage"] -= player["weapon_atack"]
            player["Equipment_weapon"] = "Меч из тёмного дерева"
            player_stats["damage"] += Dark_wood_sword["atack"]
            player["weapon_atack"] = Dark_wood_sword["atack"]
        elif "Меч из клыка змеи" in player["inventory"] and a == "Меч из клыка змеи" :
            player["inventory"].append(player["Equipment_weapon"])
            player["inventory"].remove("Меч из клыка змеи")
            player_stats["damage"] -= player["weapon_atack"]
            player["Equipment_weapon"] = "Меч из клыка змеи"
            player_stats["damage"] += Blue_snake_sword["atack"]
            player["weapon_atack"] = Blue_snake_sword["atack"]
        elif "Стальная катана" in player["inventory"] and a == "Стальная катана" :
            player["inventory"].append(player["Equipment_weapon"])
            player["inventory"].remove("Стальная катана")
            player_stats["damage"] -= player["weapon_atack"]
            player["Equipment_weapon"] = "Стальная катана"
            player_stats["damage"] += steal_katana["atack"]
            player["weapon_atack"] = steal_katana["atack"]
    elif com == 6:
        print(player["Equipment_armor"])
        print(player["Equipment_magic"])
        print(player["Equipment_weapon"])




            



while True:
    menu_option(com)

