
rase = {
    0 : "Человек",
    1 : "Эльф",
    2 : "Тёмный Эльф"
}

clas = {
    0 : "Воин" ,
    1 : "Друид" ,

}

warior = {
    "damage" : 1,
    "hp" : 50,
    "armor" : 15,
    "mana" : 25 ,
    "stamina" : 100
}

druid = {
    "damage" : 1,
    "hp" : 25,
    "armor" : 5,
    "mana" : 100 ,
    "stamina" : 100
}

Human = {   
    "damage" : 2,
    "hp" : 100,
    "armor" : 10,
    "mana" : 50 ,
    "stamina" : 100 ,
    "weapon" : "Любое оружие" ,
    "start_weapon" : "Старый меч"
}

Elf = {
    "damage" : 5,
    "hp" : 75,
    "armor" : 5,
    "mana" : 100 ,
    "stamina" : 50 ,
    "weapon" : "Любое оружие", 
    "start_weapon" : "Меч из светлого дерева"
}

dark_Elf = {
    "damage" : 10,
    "hp" : 50,
    "armor" : 10,
    "mana" : 150 ,
    "stamina" : 75 ,
    "weapon" : "Любое оружие",
    "start_weapon" : "Меч из тёмного дерева"
}
