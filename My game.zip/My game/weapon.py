

kulak = {
    "atack" : 0,
    "dop_dam" : 0,
}


#Стартовое оружие
old_sword = {
    "atack" : 5,
    "dop_dam" : 0,
}

Light_wood_sword = {
    "atack" : 6,
    "dop_dam" : 0,
}

Dark_wood_sword = {
    "atack" : 6,
    "dop_dam" : 0,
}

#покупное оружие
woolf_sword = {
    "atack" : 15,
    "dop_dam" : 0,
}

steal_sword = {
    "atack" : 10,
    "dop_dam" : 0,
}

steal_katana = {
    "atack" : 16,
}

Poison_magic = {
    "atack" : 5,
    "dop_dam" : 4,
    "mana_cost" : 10,
}

magic_arow = {
    "atack" : 15,
    "mana_cost" : 10,
    "dop_dam" : 0,
}

fire_ball = {
    "atack" : 25,
    "dop_dam" : 4,
    "mana_cost" : 20,
}

dark_wind = {
    "atack" : 50,
    "mana_cost" : 30,
    "dop_dam" : 0,
}

light_ball = {
    "atack" : 50,
    "mana_cost" : 25,
    "dop_dam" : 0,
}

atack_buff = {
    "atack" : 5,
    "mana_cost" : 25,
    "dop_dam" : 0,
}





#оружие с боссов
Blue_snake_sword = {
    "atack" : 50,
    "dop_dam" : 0,
}






