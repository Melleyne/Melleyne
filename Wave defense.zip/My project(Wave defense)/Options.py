##Файл для настроек и необязательных фишек
from library import *
from time import sleep
import json


def dificalti():
    for i in dif:
        print(i, dif[i])
    dif_opt = input("Выберите сложность: ")
    dif_opt_yesornot = input(f"Вы выбрали сложность: {dif_opt}. Вы уверены?   ")
    dif_opt_yesornot.lower()
    if dif_opt_yesornot == "да" or "yes":
        print("Отлично, добро пожаловать в игру ")
        return dif_opt
    elif dif_opt_yesornot == "нет" or "no":
        return dificalti()

