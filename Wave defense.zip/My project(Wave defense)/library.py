##Это Библиотеки для игры
from Options import *

dif = {
    "Лёгкая " : ": Слабые враги, больше опыта и денег", 
    "Нормальная " : ": Обычная сложность ", 
    "Тяжёлая " : ": Более сильные враги, меньше денег, но опыт как на нормальной", 
    "Кошмар " : ": Самые сложные враги, меньше денег и опыта, после зачистки волны здоровье и мана не восполняется, цены в магазинах выше, а торговцы приходят реже, режим для настоящих безумцев", 
}

mobs = {
    'Лёгкая': {'Бабуин' : {'health': 4, 'damage': 1, 'money' : 10, 'score' : 1, "exp" : 2},
                   'Аластра' : {'health': 8, 'damage': 3, 'money' : 6, 'score' : 1, "exp" : 2},
                   'Зомби' : {'health': 10, 'damage': 2, 'money' : 4, 'score' : 1, "exp" : 2},
                   'Скелет' : {'health': 12, 'damage': 5, 'money' : 7, 'score' : 1, "exp" : 2},
                   'Гиена' : {'health': 5, 'damage': 2, 'money' : 3, 'score' : 1, "exp" : 4},
                   'Варнир' : {'health': 12, 'damage': 4, 'money' : 15, 'score' : 4, "exp" : 4},
                   'Ходячий доспех' : {'health': 20, 'damage': 2, 'money' : 7, 'score' : 4, "exp" : 4},
                   'Кобольд' : {'health': 2, 'damage': 10, 'money' : 20, 'score' : 4, "exp" : 2},
                   'Анарх' : {'health': 18, 'damage': 5, 'money' : 20, 'score' : 4, "exp" : 8},
                   'Падальщик' : {'health': 8, 'damage': 8, 'money' : 10, 'score' : 4, "exp" : 6},
                   'Билли Бобёр' : {'health': 45, 'damage': 10, 'money' : 15, 'score' : 8, "exp" : 20},
                   'Воставший маг' : {'health': 50, 'damage': 13, 'money' : 15, 'score' : 8, "exp" : 20},
                   'Голиаф-воин' : {'health': 65, 'damage': 3, 'money' : 50, 'score' : 8, "exp" : 50},
                   'Бард' : {'health': 20, 'damage': 25, 'money' : 10, 'score' : 8, "exp" : 40},
                   'Баньши' : {'health': 8, 'damage': 50, 'money' : 50, 'score' : 8, "exp" : 40},
                   'Некромант' : {'health': 25, 'damage': 25, 'money' : 100, 'score' : 8, "exp" : 40},
                   'Бронтозавр' : {'health': 80, 'damage': 7, 'money' : 25, 'score' : 8, "exp" : 40},
                   'Виверна' : {'health': 125, 'damage': 10, 'money' : 75, 'score' : 10, "exp" : 50},
                   'Лич' : {'health': 150, 'damage': 10, 'money' : 50, 'score' : 10, "exp" : 54},
                   'Зеркальный голем' : {'health': 175, 'damage': 5, 'money' : 100, 'score' : 10, "exp" : 60},
                   'Аэрозавр ' : {'health': 275, 'damage': 7, 'money' : 150, 'score' : 20, "exp" : 200},
                   'Зимний эладрин' : {'health': 185, 'damage': 7, 'money' : 100, 'score' : 20, "exp" : 300},
                   'Тараск' : {'health': 5000, 'damage': 250, 'money' : 5000, 'score' : 100, "exp" : 200}},
    'Нормальная': {'Бабуин' : {'health': 5, 'damage': 1, 'money' : 5, 'score' : 1, "exp" : 1},
                   'Аластра' : {'health': 10, 'damage': 3, 'money' : 6, 'score' : 1, "exp" : 1},
                   'Зомби' : {'health': 12, 'damage': 2, 'money' : 4, 'score' : 1, "exp" : 1},
                   'Скелет' : {'health': 14, 'damage': 5, 'money' : 7, 'score' : 1, "exp" : 1},
                   'Гиена' : {'health': 7, 'damage': 2, 'money' : 3, 'score' : 1, "exp" : 2},
                   'Варнир' : {'health': 15, 'damage': 4, 'money' : 15, 'score' : 4, "exp" : 2},
                   'Ходячий доспех' : {'health': 25, 'damage': 2, 'money' : 7, 'score' : 4, "exp" : 2},
                   'Кобольд' : {'health': 4, 'damage': 10, 'money' : 20, 'score' : 4, "exp" : 1},
                   'Анарх' : {'health': 20, 'damage': 5, 'money' : 20, 'score' : 4, "exp" : 4},
                   'Падальщик' : {'health': 10, 'damage': 8, 'money' : 10, 'score' : 4, "exp" : 3},
                   'Билли Бобёр' : {'health': 50, 'damage': 10, 'money' : 15, 'score' : 8, "exp" : 10},
                   'Воставший маг' : {'health': 55, 'damage': 13, 'money' : 15, 'score' : 8, "exp" : 10},
                   'Голиаф-воин' : {'health': 70, 'damage': 3, 'money' : 50, 'score' : 8, "exp" : 25},
                   'Бард' : {'health': 25, 'damage': 25, 'money' : 10, 'score' : 8, "exp" : 20},
                   'Баньши' : {'health': 10, 'damage': 50, 'money' : 50, 'score' : 8, "exp" : 20},
                   'Некромант' : {'health': 30, 'damage': 25, 'money' : 100, 'score' : 8, "exp" : 20},
                   'Бронтозавр' : {'health': 100, 'damage': 7, 'money' : 25, 'score' : 8, "exp" : 20},
                   'Виверна' : {'health': 150, 'damage': 10, 'money' : 75, 'score' : 10, "exp" : 25},
                   'Лич' : {'health': 175, 'damage': 10, 'money' : 50, 'score' : 10, "exp" : 27},
                   'Зеркальный голем' : {'health': 200, 'damage': 5, 'money' : 100, 'score' : 10, "exp" : 30},
                   'Аэрозавр ' : {'health': 300, 'damage': 7, 'money' : 150, 'score' : 20, "exp" : 100},
                   'Зимний эладрин' : {'health': 200, 'damage': 7, 'money' : 100, 'score' : 20, "exp" : 150},
                   'Тараск' : {'health': 5000, 'damage': 250, 'money' : 5000, 'score' : 100, "exp" : 100}},
    'Тяжёлая': {'Бабуин' : {'health': 7, 'damage': 2, 'money' : 4, 'score' : 1, "exp" : 1},
                   'Аластра' : {'health': 13, 'damage': 5, 'money' : 6, 'score' : 1, "exp" : 1},
                   'Зомби' : {'health': 16, 'damage': 3, 'money' : 4, 'score' : 1, "exp" : 1},
                   'Скелет' : {'health': 17, 'damage': 6, 'money' : 7, 'score' : 1, "exp" : 1},
                   'Гиена' : {'health': 10, 'damage': 3, 'money' : 3, 'score' : 1, "exp" : 1},
                   'Варнир' : {'health': 25, 'damage': 5, 'money' : 15, 'score' : 4, "exp" : 1},
                   'Ходячий доспех' : {'health': 32, 'damage': 4, 'money' : 7, 'score' : 4, "exp" : 1},
                   'Кобольд' : {'health': 6, 'damage': 14, 'money' : 20, 'score' : 4, "exp" : 1},
                   'Анарх' : {'health': 25, 'damage': 8, 'money' : 20, 'score' : 4, "exp" : 3},
                   'Падальщик' : {'health': 15, 'damage': 10, 'money' : 10, 'score' : 4, "exp" : 2},
                   'Билли Бобёр' : {'health': 67, 'damage': 13, 'money' : 15, 'score' : 8, "exp" : 8},
                   'Воставший маг' : {'health': 63, 'damage': 17, 'money' : 15, 'score' : 8, "exp" : 8},
                   'Голиаф-воин' : {'health': 83, 'damage': 5, 'money' : 50, 'score' : 8, "exp" : 20},
                   'Бард' : {'health': 30, 'damage': 35, 'money' : 10, 'score' : 8, "exp" : 18},
                   'Баньши' : {'health': 25, 'damage': 67, 'money' : 50, 'score' : 8, "exp" : 18},
                   'Некромант' : {'health': 35, 'damage': 38, 'money' : 100, 'score' : 8, "exp" : 18},
                   'Бронтозавр' : {'health': 125, 'damage': 15, 'money' : 25, 'score' : 8, "exp" : 18},
                   'Виверна' : {'health': 162, 'damage': 16, 'money' : 75, 'score' : 10, "exp" : 20},
                   'Лич' : {'health': 200, 'damage': 12, 'money' : 50, 'score' : 10, "exp" : 24},
                   'Зеркальный голем' : {'health': 254, 'damage': 10, 'money' : 100, 'score' : 10, "exp" : 25},
                   'Аэрозавр ' : {'health': 358, 'damage': 12, 'money' : 150, 'score' : 20, "exp" : 85},
                   'Зимний эладрин' : {'health': 400, 'damage': 9, 'money' : 100, 'score' : 20, "exp" : 125},
                   'Тараск' : {'health': 5000, 'damage': 260, 'money' : 5000, 'score' : 100, "exp" : 8}},
    


}
weapon_list = {
    "Кулаки" : {"damage" : 1, "price" : 0},
    "Ржавый меч" : {"damage" : 2, "price" : 5},
    "Осенённый луной меч" : {"damage" : 3, "price" : 10},
    "Кровавое копьё" : {"damage" : 4, "price" : 15},
    "Сияющий клевец" : {"damage" : 5, "price" : 20},
    "Громобой" : {"damage" : 8, "price" : 50},
    "Сокрушитель сумерек" : {"damage" : 10, "price" : 65},
    "Чёрный клинок" : {"damage" : 15, "price" : 150},
    "Волна" : {"damage" : 20, "price" : 250},
    "Крик Жнеца" : {"damage" : 25, "price" : 350},
    "Солнечный меч" : {"damage" : 37, "price" : 450},
    "Лунный клинок" : {"damage" : 45, "price" : 675},
    "Высекающий искры" : {"damage" : 65, "price" : 1000},
}




player = {
    "inventory" : [] ,
    "money" : 0 ,
    "hp" : 100,
    "exp" : 0,
    "lvl" : 1,
    "skill_points" : 0,
    "damage" : 2,
    "mana" : 100,
    "Equipment_weapon" : "Кулаки",
    "Weapon_damage" : 1,
    "Equipment_armor" : "Повседневная одежда",
    "Equipment_magic" : "Магический свет",
}

spell_list = {
    "Магический свет" : {"damage" : 1, "price" : 0, "mana" : 1},
}



fight_option = {
    1 : "Атаковать",
    2 : "Инвентарь",
}


com_list = {
    1 : "Защита волн",
    2 : "Магазин",
    3 : "Прокачка",
    4 : "Сохранение",
}
shop_list = {
    1 : "Оружейный магазин",
    2 : "Магазин зельевара",
}

skill_tree  = {
    1 : "Здоровье",
    2 : "Урон",
    3 : "Мана",
}


hp_potion_list = {
    "Малое зелье здоровья" : {"hp" : 10, "price" : 5},
    "Слабое зелье здоровья" : {"hp" : 25, "price" : 50},
    "Среднее зелье здоровья" : {"hp" : 50, "price" : 100},
    "Большое зелье здоровья" : {"hp" : 75, "price" : 150},    
    "Гигантское зелье здоровья" : {"hp" : 100, "price" : 200},           
}

mana_potion_list = {
    "Малое зелье маны" : {"mana" : 10, "price" : 5},
    "Слабое зелье маны" : {"mana" : 25, "price" : 50},
    "Среднее зелье маны" : {"mana" : 50, "price" : 100},
    "Большое зелье маны" : {"mana" : 75, "price" : 150},    
    "Гигантское зелье маны" : {"mana" : 100, "price" : 200}      
}
