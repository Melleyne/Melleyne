## сдесь хрантся запуск игры 
from Options import *
from library import *
import random 
import json
import math










print("Добро поаловать в Wave defense: ")
save_opt = int(input("Вы желаете начать с нуля:  "))

if save_opt == 1 : 
    with open('save.pkl', 'w') as file:
        json.dump([player], file)
    current_wave = 1
    wave_score = 1
    for i in dif:
        print(i, dif[i])
    dif_opt = input("Выберите сложность: ")
    print(f"Вы выбрали сложность: {dif_opt}")
else:
    with open('save_player_data.pkl', 'r') as file:
        player = json.load(file)
    with open('save.pkl', 'r') as file:
        save_lib = json.load(file)
        dif_opt = save_lib[0]["dif"]
        current_wave = save_lib[0]["wave"]
        wave_score = save_lib[0]["wave_score"]
    


save_lib = {
    "dif" : dif_opt,
    "wave" : current_wave,
    "wave_score" : wave_score,
}


while True:
    print("-----------------------------------------------------------------------------------------")
    print("Вы находитесь в меню: ")
    for i in com_list:
        print(f"{i} - {com_list[i]}")
    sleep(1)
    a = int(input("Выбери действие: "))
    print("-----------------------------------------------------------------------------------------")
    if a == 1:
        wave_score_buffer = wave_score
        while wave_score_buffer != 0:
            current_wave_score = wave_score
            atack_mob = random.choice(list(mobs[dif_opt].keys()))
            mob_stats = mobs[dif_opt][atack_mob]
            mob_damage = mob_stats["damage"]
            mob_health = mob_stats["health"]
            mob_money = mob_stats["money"]
            mob_score = mob_stats["score"]
            mob_exp = mob_stats["exp"]      
            if mob_score > current_wave_score:
                continue
            else:
                #место под файт
                weapon = player["Equipment_weapon"]
                magic = player["Equipment_magic"]
                magic_damage = spell_list[player["Equipment_magic"]]["damage"]
                magic_mana = spell_list[player["Equipment_magic"]]["mana"]
                hp = player["hp"]
                mana = player["mana"]
                player["Weapon_damage"] = weapon_list[player["Equipment_weapon"]]["damage"]
                player_damage = player["damage"] + player["Weapon_damage"]
                new_lvl = player["lvl"] * 100 + 150
                print(f"На вас напал {atack_mob}.")
                sleep(1)
                while mob_health < 0 or hp > 0:
                    print(f"{atack_mob} наносит удар")
                    hp = hp - mob_damage 
                    print(f"Здоровье игрока : {hp}, удар нанёс {mob_damage}")
                    sleep(1)
                    print("-----------------------------------------------------------------------------------------")
                    for i in fight_option:
                        sleep(1)
                        print(fight_option[i])
                    first_step =  input(" Выберите действие:  ")
                    if first_step == "Атаковать":
                        if player["lvl"] >= 10:
                            print(f"Вы наносите удар при помощи {weapon}")
                            sleep(1)
                            print(f"Вы нанесли: {player_damage}")
                            mob_health = mob_health - player_damage
                            print(f"Здоровье врага:  {mob_health}")
                            if mana >= magic_mana:
                                print(f"Вы наносите второй удар при помощи {magic}")
                                sleep(1)
                                print(f"Вы нанесли: {magic_damage}")
                                mob_health = mob_health - magic_damage
                                print(f"Здоровье врага:  {mob_health}")
                            else:
                                mana_cost = magic_mana - mana
                                print(f"Недостаточно маны, нужно ещё {mana_cost} маны")
                        else:
                            print(f"Вы наносите удар при помощи {weapon}")
                            sleep(1)
                            print(f"Вы нанесли: {player_damage}")
                            mob_health = mob_health - player_damage
                            print(f"Здоровье врага:  {mob_health}")
                    elif first_step == "Инвентарь":
                        potions_opt_list = int(input("Выберите тип зелья: 1 - здоровье, 2 - мана"))
                        if potions_opt_list == 1:
                            for i in player["inventory"]:
                                print(player["inventory"])
                            potion_opt = input("Введите название зелья из инвентаря:  ")
                            if potion_opt in player["inventory"]:
                                hp += potion_opt["hp"]
                                player["inventory"].remove(potion_opt)
                        elif potions_opt_list == 2:
                            for i in player["inventory"]:
                                print(player["inventory"])
                            potion_opt = input("Введите название зелья из инвентаря:  ")
                            if potion_opt in player["inventory"]:
                                mana += potion_opt["mana"]
                                player["inventory"].remove(potion_opt)
                        

                    if mob_health <= 0:
                        sleep(1)
                        print("Ты победил!")
                        player["money"] += mob_money
                        player["exp"] += mob_exp
                        wave_score_buffer -= mob_score
                        while player["exp"] >= new_lvl:
                            player["lvl"] += 1
                            new_player_exp = player["exp"] - new_lvl
                            player["exp"] = new_player_exp
                            lvl = player["lvl"]
                            player["skill_points"] += 3
                            skills = player["skill_points"]
                            print(f"Уровень повышен! Теперт ваш уровень {lvl}")
                            print(f"Тебе доступно {skills} очков")
                        break

                    elif hp <= 0:
                        print("Ты проиграл")
                        current_wave_score += mob_score
                        break

            if wave_score_buffer == 0:
                current_wave += 1
                current_wave_bufer = current_wave % 10
                if current_wave_bufer != 0:
                    wave_score = wave_score + current_wave
                else:
                    wave_score = wave_score + current_wave
                break
    

    elif a == 2:
        player_money = player["money"]
        print("Добро пожаловать в магазин! ")
        print(f"На данный момент у тебя {player_money} монет")
        print("Выберите отдел магазина: ")
        for i in shop_list:
            sleep(0.1)
            print(f"{i} - {shop_list[i]}")
        shop_opt = int(input("==>> "))
        if shop_opt == 1:
            for i in weapon_list:
                sleep(0.1)
                print( i, " - ", weapon_list[i]["damage"], "урона, стоит ",  weapon_list[i]["price"], "монет")
            weapon_buy = input("Введите название оружия:   ")
            if weapon_buy in weapon_list and player["money"] >= weapon_list[weapon_buy["price"]]:
                player["inventory"].append(weapon_buy)
                option = input("Вы желаете экепировать новое оружие?  ")
                option.lower()
                if option == "да" or "yes":
                    player["inventory"].append(player["Equipment_weapon"])
                    player["Equipment_weapon"] = weapon_buy
                    player["inventory"].remove(weapon_buy)

        elif shop_opt == 2:
            for i in hp_potion_list:
                sleep(0.1)
                print(i, " - ", hp_potion_list[i]["hp"], "здоровья, стоит ",  hp_potion_list[i]["price"], "монет")
            print("------------------------------------------------------------------------------")
            for i in mana_potion_list:
                sleep(0.1)
                print(i, " - ", mana_potion_list[i]["mana"], "маны, стоит ",  mana_potion_list[i]["price"], "монет")
            potion_buy  = input("Введите название зелья:   ")
            if potion_buy in hp_potion_list and player["money"] >= hp_potion_list[potion_buy["price"]]:
                player["inventory"].append(potion_buy)
            elif potion_buy in mana_potion_list and player["money"] >= mana_potion_list[potion_buy["price"]]:
                player["inventory"].append(potion_buy)
            
    elif a == 3:
        skill_point = player["skill_points"]
        print("Добро пожаловать в древо прокачки")
        print(f"У теяб доступно: {skill_point}")
        for i in skill_tree:
            print(i, skill_tree)
        st = int(input("Введите желаемую прокачку:  "))
        if st == 1:
            if player["skill_points"] >= 1:
                player["hp"] += 50
                player["skill_points"] -= 1
            else:
                print("Недостаточно очков прокачки")
        elif st == 2:
             if player["skill_points"] >= 1:
                player["damage"] += 1
                player["skill_points"] -= 1
             else:
                print("Недостаточно очков прокачки")
        elif st == 3:
             if player["skill_points"] >= 1:
                player["mana"] += 25
                player["skill_points"] -= 1
             else:
                print("Недостаточно очков прокачки")
    elif a == 4:
        with open('save_player_data.pkl', 'w') as file:
            json.dump([player], file)
        with open('save.pkl', 'w') as file:
            json.dump([save_lib], file)
        print("Сохранение завершино")
    elif a == 5:
        print(player, current_wave, wave_score)